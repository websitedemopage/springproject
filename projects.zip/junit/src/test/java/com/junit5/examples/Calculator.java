package com.junit5.examples;

public class Calculator {
    public int multiply(int a, int b) {
        return a * b;
    }
    
    public static int add(int i, int j) {
		return i + j;
	}

}

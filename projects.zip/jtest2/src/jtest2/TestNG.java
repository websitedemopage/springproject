package jtest2;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TestNG {
    @Test
    public void f() {
    }
 
    @BeforeTest
    public void beforeTest() {
    }
 
    @AfterTest
    public void afterTest() {
    }
}
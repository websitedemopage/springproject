package jtest2;

import org.testng.annotations.Factory;
import org.testng.annotations.Test;
public class SimpleTestFactory1 {
	
    @Factory
    public Object[] factoryMethod() {
        return new Object[] { new SimpleTest1(0), new SimpleTest1(1) };
    }

}